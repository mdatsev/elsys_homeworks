package org.elsys.cardgame.api;

public interface VoidGameAction{
	void action(Game game);
}