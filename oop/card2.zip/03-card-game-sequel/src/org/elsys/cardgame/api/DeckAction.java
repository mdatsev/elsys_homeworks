package org.elsys.cardgame.api;

public interface DeckAction{
	Object action(Deck game);
}