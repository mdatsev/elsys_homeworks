package org.elsys.cardgame.api;

public interface GameAction{
	Object action(Game game);
}