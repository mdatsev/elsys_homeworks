package org.elsys.cardgame.api;

public interface VoidDeckAction{
	void action(Deck deck);
}