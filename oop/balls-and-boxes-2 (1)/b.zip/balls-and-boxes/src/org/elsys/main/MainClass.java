package org.elsys.main;

public class MainClass {
    public void main(String[] Args)
    {

    }
}
