package org.elsys.todo;

public enum Status {
	TODO, DOING, DONE
}
