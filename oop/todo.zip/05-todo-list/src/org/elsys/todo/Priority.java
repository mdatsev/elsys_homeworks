package org.elsys.todo;

public enum Priority {
	HIGH, NORMAL, LOW
}
