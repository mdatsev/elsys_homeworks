#ifndef _DUMB_SHM_STRUCT
#define _DUMB_SHM_STRUCT

struct shared_mem
{
	char lala[0];
};

#endif
